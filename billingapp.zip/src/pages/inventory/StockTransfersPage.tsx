import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { stockTransfersApi, warehousesApi } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus } from "lucide-react";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { StatusBadge } from "@/components/StatusBadge";

export default function StockTransfersPage() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ from_warehouse_id: "", to_warehouse_id: "", notes: "" });

  const { data: transfers = [], isLoading } = useQuery({
    queryKey: ["stock_transfers"],
    queryFn: () => stockTransfersApi.list(),
  });

  const { data: warehouses = [] } = useQuery({
    queryKey: ["warehouses"],
    queryFn: () => warehousesApi.list(),
  });

  const createMut = useMutation({
    mutationFn: () => stockTransfersApi.create({
      document_number: `ST-${Date.now()}`,
      from_warehouse_id: form.from_warehouse_id || null,
      to_warehouse_id: form.to_warehouse_id || null,
      notes: form.notes,
    }, []),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["stock_transfers"] }); setOpen(false); toast({ title: "Transfer created" }); },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-foreground">Stock Transfers</h1>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button size="sm"><Plus className="w-4 h-4 mr-1" /> New Transfer</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>New Stock Transfer</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <Select value={form.from_warehouse_id} onValueChange={(v) => setForm({ ...form, from_warehouse_id: v })}>
                <SelectTrigger><SelectValue placeholder="From Warehouse" /></SelectTrigger>
                <SelectContent>{warehouses.map((w: any) => <SelectItem key={w.id} value={w.id}>{w.warehouse_name || w.warehouseName}</SelectItem>)}</SelectContent>
              </Select>
              <Select value={form.to_warehouse_id} onValueChange={(v) => setForm({ ...form, to_warehouse_id: v })}>
                <SelectTrigger><SelectValue placeholder="To Warehouse" /></SelectTrigger>
                <SelectContent>{warehouses.map((w: any) => <SelectItem key={w.id} value={w.id}>{w.warehouse_name || w.warehouseName}</SelectItem>)}</SelectContent>
              </Select>
              <Input placeholder="Notes" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
              <Button onClick={() => createMut.mutate()} className="w-full">Create</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
      <div className="border border-border rounded-lg overflow-hidden">
        <Table>
          <TableHeader><TableRow>
            <TableHead>Number</TableHead><TableHead>Date</TableHead><TableHead>Status</TableHead><TableHead>Notes</TableHead>
          </TableRow></TableHeader>
          <TableBody>
            {isLoading ? <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">Loading...</TableCell></TableRow> :
            transfers.length === 0 ? <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">No transfers</TableCell></TableRow> :
            transfers.map((t: any) => (
              <TableRow key={t.id}>
                <TableCell className="font-medium">{t.document_number || t.documentNumber}</TableCell>
                <TableCell>{t.date}</TableCell>
                <TableCell><StatusBadge status={t.status} /></TableCell>
                <TableCell className="text-muted-foreground">{t.notes}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
